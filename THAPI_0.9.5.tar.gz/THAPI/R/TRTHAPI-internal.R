library(RCurl)
library(XML)
library(base64)

options("digits.secs"=6)

# Global variable 
THAPI <- "https://trth-api.thomsonreuters.com/TRTHApi-5.8/services/TRTHApi"
THWS <- "http://webservice.tickhistory.thomsonreuters.com"
THNS <- 'xmlns="http://types.webservice.tickhistory.thomsonreuters.com"'
HTTPHEADER <- c('Accept'="text/html", 'Accept'="multipart/*",'Content-type'="text/html; charset=utf-8", SOAPAction=THWS)
THDEBUG <- "false"


# Creates a class called rdth
setClass("rdth", representation(user="character",password="character", token="character"))

setGeneric("serialize",function(this) standardGeneric("serialize"))
setMethod("serialize","rdth",
	function(this){
		paste("<?xml version='1.0' encoding='utf-8'?><soap:Envelope xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' xmlns:xsd='http://www.w3.org/2001/XMLSchema' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'>", "<soap:Header><CredentialsHeader xmlns='http://types.webservice.tickhistory.thomsonreuters.com'><username>",this@user,"</username><password>",this@password,"</password><tokenId>",this@token,"</tokenId></CredentialsHeader></soap:Header>",sep="")
	}
)

setGeneric("createCredential", function(user, password) standardGeneric("createCredential"))
setMethod("createCredential", signature(user="character", password="character"),
        function(user, password){
		rdth <- new("rdth", user=user, password=password)
                tmp=serialize(rdth)
                tmp=paste(tmp, "<soap:Body>", sep="")
                tmp=paste(tmp, "<GetQuota></GetQuota>", sep="")
                tmp = paste(tmp, "</soap:Body></soap:Envelope>", sep="")

               	xml = basicTextGatherer()
                curlPerform(url = THAPI,  httpheader=c('Accept'="text/xml", 'Accept'="multipart/*",'Content-Type'="text/xml; charset=utf-8",
                                SOAPAction=THWS), postfields=tmp, writefunction=xml$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))

		tmpToken <- ""
		xmlTreeParse(xml$value(),handlers=list(CredentialsHeader=function(x){
				tmpToken <<- xmlValue(x[3]$tokenId)
		}))
	
		rdth@token <- tmpToken		
		rdth
        }
)


#InflightStatus
setClass("InFlightStatus", representation(active="character", limit="character", completed="vector"))

#Version
setClass("Version", representation(servlet="character", backend="character"))

#Data
setClass("Data", representation(type="character", field="character", value="character", longName="character"), prototype = list(type="", field="", value="", longName=""))
setMethod("serialize", "Data", 
	function(this){
		c = "<data>"
		if (nchar(this@type)>0){
			c = paste(c,"<type>", this@type, "</type>",sep="")
		}
		if (nchar(this@field)>0){
			c = paste(c,"<field>",this@field,"</field>",sep="")
		}
		if (nchar(this@value)>0){
			c = paste(c,"<value>",this@value,"</value>", sep="")
		}
		if (nchar(this@longName)>0){
			c = paste(c, "<longName>", this@longName, "</longName>", sep="")
		}
		c = paste(c, "</data>",sep="")		
	}	
)


setClass("QuotaType", representation(value="character"))  

setClass("Quota", representation(type="QuotaType", usedCash="character", totalCash="character", usedOption="character", totalOption="character", usedFuture="character", totalFuture="character", exceedable="character"))  
			
#Complex Types
setClass("ArrayOfData", representation(v="vector"))
setGeneric("convertToString", function(this) standardGeneric("convertToString"))
setMethod("convertToString", "vector",
	function(this){
		c=""
		for (each in this){	
			if (c==""){
				c <- each
			}else{		
				d <- paste(c,each,sep="->")    	
			}	
		}
		c
	}
)

setMethod("serialize", "ArrayOfData",
	function(this){
		c=""
		for (each in this@v){
			c = paste(c, serialize(each), sep="")
		}
		c
	}
)

#Currencies
setClass("Currency", representation(countries="ArrayOfData"))
setMethod("serialize","Currency", 
	function(this){
		serialize(this)			
	}
) 

# Exchanges
setClass("Exchange", representation(domains="ArrayOfData"))
setMethod("serialize","Exchange",
	function(this){	
		serialize(this)
	}
)

#DateRange
setClass("DateRange", representation(start="character",end="character")) 
setMethod("serialize","DateRange",
	function(this){
		tmp = "<dateRange>"
		tmp = paste(tmp, "<start>", this@start, "</start>", "<end>", this@end, "</end>", sep="")
		tmp = paste(tmp, "</dateRange>", sep="")
	}
) 

#TimeRange
setClass("TimeRange", representation(start="character",end="character"))
setMethod("serialize", "TimeRange", 
	function(this){
		tmp = "<timeRange>"
		tmp = paste(tmp, "<start>", this@start, "</start>", "<end>", this@end, "</end>", sep="")
		tmp = paste(tmp, "</timeRange>", sep="")
	}
)

setClass("Criteria", representation(d = "ArrayOfData"))
setMethod("serialize", "Criteria", 
	function(this){
		c="<criteria>"
		c = paste(c, serialize(this@d), sep="")		
		c = paste(c, "</criteria>")
	}
)

setClass("InstrumentStatus", representation(status="character"))
setMethod("serialize", signature(this="InstrumentStatus"), 
	function(this){
		tmp = "<InstrumentStatus>"
		tmp = paste(tmp,this@status , "</InstrumentStatus>")
		tmp
	}
)

#InstrumentList
setClass("InstrumentList", representation(data="vector"))
setMethod("serialize","InstrumentList", 
	function(this){
		tmp = "<instrumentList>"
		for (each in this@data){
			i = new ("Instrument", code=each)
			tmp = paste(tmp, serialize(i), sep="")			
		}
		tmp = paste(tmp, "</instrumentList>", sep="")
	}
)


#InstrumentType
setClass("InstrumentType", representation(value="numeric", longName="character"))

#InstrumentList handler
	
#CountryList
setClass("CountryList", representation(data="vector"))
setMethod("serialize", "CountryList", 
	function(this){
		tmp = "<countryList>"
		for(each in this@data){
			tmp = paste(tmp,"<data><value>", each, "</value></data>", sep="")
		}   				
		tmp = paste(tmp, "</countryList>", sep="")
	}
)

#DomainList
setClass("DomainList", representation(data="vector"))
setMethod("serialize", "DomainList", 
	function(this){
		tmp = "<domainList>"
		for(each in this@data){
			tmp = paste(tmp, "<data><value>", each, "</value></data>", sep="")
		}
		tmp = paste(tmp, "</domainList>", sep="")
	}
)
					
#FieldList
setClass("FieldList", representation(data="vector"))
setMethod("serialize", "FieldList", 
	function(this){
		tmp = "<fieldList>"
		for(each in this@data){
			tmp = paste(tmp, "<string>", each, "</string>", sep="")
		}	
		tmp = paste(tmp, "</fieldList>", sep="")
	}
)

#MessageType
setClass("MessageType", representation(name="character", fieldList="FieldList"))
setMethod("serialize", "MessageType", 
	function(this){
		tmp = "<messageType>"
		tmp = paste(tmp, "<name>", this@name, "</name>",  sep="")
		tmp = paste(tmp, serialize(this@fieldList))
		tmp = paste(tmp, "</messageType>", sep="")
	})

#MessageTypeList
setClass("MessageTypeList", representation(data="ArrayOfData"))
setMethod("serialize", "MessageTypeList", 
	function(this){
		tmp = "<messageTypeList>"
		tmp = paste(tmp, serialize(this@data), sep="")
		tmp = paste(tmp, "</messageTypeList>", sep="")
	}
)

#Instrument
setClass("Instrument", representation(code="character",isin="ArrayOfData",cusip="ArrayOfData",sedol="ArrayOfData",gics="ArrayOfData",dateRange="DateRange",name="ArrayOfData", status="InstrumentStatus",statusInfo="character",exchange="ArrayOfData", type="ArrayOfData", expiryDate="ArrayOfData",strikePrice="ArrayOfData",maturityDate="ArrayOfData",couponDate="ArrayOfData",bondType="ArrayOfData",creditRating="ArrayOfData",currency="ArrayOfData",optionType="ArrayOfData",peCode="ArrayOfData",underlyingRIC="ArrayOfData",releaseCycle="ArrayOfData"))
setMethod("serialize","Instrument",
	function(this){	
		tmp = "<instrument>"	
		if (nchar(this@code) >0){
			tmp=paste(tmp, "<code>",this@code, "</code>",sep="")
		}	
		if (length(this@isin@v) >0){
                        tmp = paste(tmp, "<isin>", serialize(this@isin), "</isin>", sep="")
                }
                if (length(this@cusip@v)>0){
                        tmp = paste(tmp, "<cusip>", serialize(this@cusip), "</cusip>", sep="")
                }
                if (length(this@sedol@v)>0){
                        tmp = paste(tmp, "<sedol>", serialize(this@sedol), "</sedol>", sep="")
                }
                if (length(this@gics@v)>0){
                        tmp = paste(tmp, "<gics>", serialize(this@gics), "</gics>", sep="")
                }
                if (length(this@dateRange@start)>0 || length(this@dateRange@start)>0){
                        tmp = paste(tmp, serialize(this@dateRange), sep="")
                }
                if (length(this@name@v)>0){
                        tmp = paste(tmp, serialize(this@name), sep="")
                }
                if (length(this@status@status)>0){
                        tmp = paste(tmp, serialize(this@status), sep="")
                }
                if (length(this@statusInfo >0)){
                        tmp = paste(tmp, "<statusInfo>", this@statusInfo, "</statusInfo>", sep="")
                }
                if (length(this@exchange@v)>0){
                        tmp = paste(tmp, serialize(this@exchange), sep="")
                }
                if (length(this@type@v)>0){
                        tmp = paste(tmp, serialize(this@type), sep="")
                }
                if (length(this@expiryDate@v)>0){
                        tmp = paste(tmp, serialize(this@expiryDate), sep="")
                }
                if (length(this@strikePrice@v)>0){
                        tmp = paste(tmp, serialize(this@strikePrice), sep="")
                }
		tmp = paste(tmp, "</instrument>",sep="")
		tmp
	}
) 



#RequestSpec
setClass("RequestSpec", 
		representation(friendlyName="character",requestType="character", instrument="Instrument", date="character",
				timeRange="TimeRange", messageTypeList="MessageTypeList", 
				requestInGMT="character", displayInGMT="character",disableHeader="character",
				marketDepth="character",dateFormat="character",disableDataPersistence="character",
				includeCurrentRIC="character",applyCorrections="character", displayMicroseconds="character"))

setMethod("serialize", "RequestSpec", 
	function(this){
		tmp = "<request>"
		tmp = paste(tmp, "<friendlyName>", this@friendlyName, "</friendlyName>", sep="")
		tmp = paste(tmp, "<requestType>", this@requestType, "</requestType>", sep="")
		tmp = paste(tmp, serialize(this@instrument), sep="")
		tmp = paste(tmp, "<date>", this@date, "</date>", sep="")
		tmp = paste(tmp, serialize(this@timeRange), sep="")
		tmp = paste(tmp, serialize(this@messageTypeList), sep="")
		tmp = paste(tmp, "<requestInGMT>", this@requestInGMT, "</requestInGMT>", sep="")
		tmp = paste(tmp, "<displayInGMT>", this@displayInGMT, "</displayInGMT>", sep="")
		tmp = paste(tmp, "<disableHeader>", this@disableHeader, "</disableHeader>", sep="")
		tmp = paste(tmp, "<marketDepth>", this@marketDepth, "</marketDepth>", sep="")
		tmp = paste(tmp, "<dateFormat>", this@dateFormat, "</dateFormat>", sep="")
		tmp = paste(tmp, "<disableDataPersistence>", this@disableDataPersistence, "</disableDataPersistence>", sep="")
		tmp = paste(tmp, "<includeCurrentRIC>", this@includeCurrentRIC, "</includeCurrentRIC>", sep="")
		tmp = paste(tmp, "<applyCorrections>", this@applyCorrections, "</applyCorrections>", sep="")
		tmp = paste(tmp, "<displayMicroseconds>", this@displayMicroseconds, "</displayMicroseconds>", sep="")
		tmp = paste(tmp, "</request>", sep="")
	}	
)


#LargeRequestSpec
setClass("LargeRequestSpec", 
		representation(friendlyName="character", requestType="character", 
				instrumentList="InstrumentList", dateRange="DateRange", timeRange="TimeRange",
				messageTypeList="MessageTypeList", requestInGMT="character", displayInGMT="character", 
				marketDepth="character", splitSize="character", delivery="character",sortType="character", 
				fileFormat="character", dateFormat="character", disableDataPersistence="character", includeCurrentRIC="character", 
				applyCorrections="character", displayMicroseconds="character" 
			 ))

setMethod("serialize", "LargeRequestSpec", 
	function(this){
		tmp = "<request>"
		tmp = paste(tmp, "<friendlyName>", this@friendlyName, "</friendlyName>", sep="")
		tmp = paste(tmp, "<requestType>", this@requestType, "</requestType>", sep="") 
		tmp = paste(tmp, serialize(this@instrumentList), sep="")
		tmp = paste(tmp, serialize(this@dateRange), sep="")
		tmp = paste(tmp, serialize(this@timeRange), sep="")
		tmp = paste(tmp, serialize(this@messageTypeList), sep="")
		tmp = paste(tmp, "<requestInGMT>", this@requestInGMT, "</requestInGMT>", sep="")
		tmp = paste(tmp, "<displayInGMT>", this@displayInGMT, "</displayInGMT>", sep="")
		tmp = paste(tmp, "<marketDepth>", this@marketDepth, "</marketDepth>", sep="")
		tmp = paste(tmp, "<splitSize>", this@splitSize, "</splitSize>", sep="") 
		tmp = paste(tmp, "<delivery>", this@delivery, "</delivery>", sep="")
		tmp = paste(tmp, "<sortType>", this@sortType, "</sortType>", sep="")
		tmp = paste(tmp, "<fileFormat>", this@fileFormat, "</fileFormat>", sep="")
		tmp = paste(tmp, "<dateFormat>", this@dateFormat, "</dateFormat>", sep="")
		tmp = paste(tmp, "<disableDataPersistence>", this@disableDataPersistence, "</disableDataPersistence>", sep="")
		tmp = paste(tmp, "<includeCurrentRIC>", this@includeCurrentRIC, "</includeCurrentRIC>", sep="")
		tmp = paste(tmp, "<applyCorrections>", this@applyCorrections, "</applyCorrections>", sep="")
		tmp = paste(tmp, "<displayMicroseconds>", this@displayMicroseconds, "</displayMicroseconds>", sep="")
		tmp = paste(tmp, "</request>", sep="")
	}
)	


######################
### TH Functions #####
######################


########
# GetExchanges
# Returns a list of supported exchange codes for a given list of Asset Domains. 
#
# Example: 
# getExchanges(rdth) 

setGeneric("getExchanges", function(this,domains) standardGeneric("getExchanges"))
setMethod("getExchanges", signature(this="rdth", domains="vector"),  
	function(this, domains){
		tmp = serialize(this)	 
		tmp = paste(tmp, "<soap:Body>", sep="")
		domainList = new("DomainList", data=domains)
		tmp = paste(tmp, "<GetExchanges>", serialize(domainList), "</GetExchanges>", sep="")  
		tmp = paste(tmp, "</soap:Body></soap:Envelope>", sep="")

		exchanges = basicTextGatherer()
		curlPerform(url = THAPI,  httpheader=c('Accept'="text/xml", 'Accept'="multipart/*",'Content-Type'="text/xml; charset=utf-8", SOAPAction=THWS), postfields=tmp, writefunction=exchanges$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))

		ret <- data.frame()
		xmlTreeParse(exchanges$value(),handlers=list(exchangeList=function(x){
				i<-1;
                                while(i<=length(x)){
						ret <<- rbind(ret, data.frame(
                                                value=xmlValue(x[i]$data[3]$value),longName=xmlValue(x[i]$data[4]$longName)))
                                        i <- i+1
                                }
                        }), asTree=TRUE)	
		ret			

	}		
)



################
# GetCurrencies
# Returns a list of supported currency codes for a given list of country codes
#
# Example:
# getCurrenciesdth, countries=c("Australia"))

setGeneric("getCurrencies", function(this,countries) standardGeneric("getCurrencies"))
setMethod("getCurrencies", signature(this="rdth", countries="vector"), 
	function(this,countries){
		tmp = serialize(this)
		tmp = paste(tmp, "<soap:Body>", sep="")
		countryList = new("CountryList", data=countries)
		tmp = paste(tmp, "<GetCurrencies xmlns='http://types.webservice.tickhistory.thomsonreuters.com'>", serialize(countryList), "</GetCurrencies>", sep="")
		tmp = paste(tmp, "</soap:Body></soap:Envelope>", sep="")

		currencies = basicTextGatherer()
		curlPerform(url = THAPI,  httpheader=c('Accept'="text/xml", 
			'Accept'="multipart/*",'Content-Type'="text/xml; charset=utf-8", 
			SOAPAction=THWS), postfields=tmp, 
			writefunction=currencies$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))

		ret <- data.frame()
                xmlTreeParse(currencies$value(), handlers=list(currencyList=function(x){	
				i<-1;
                                while(i<=length(x)){
						ret <<- rbind(ret, data.frame(	
                                                value=xmlValue(x[i]$data[3]$value),
                                                longName=xmlValue(x[i]$data[4]$longName)))
                                        i <- i+1
                                }
                        }), asTree=TRUE)	
		ret					
	}
)



##############
# GetBondTypes
#
# Example:
# Returns a list of bond type codes applicable to instruments from the fixed income domain. 

setGeneric("getBondTypes", function(this) standardGeneric("getBondTypes"))
setMethod("getBondTypes", signature(this="rdth"), 
	function(this){
		tmp = serialize(this)
		tmp = paste(tmp, "<soap:Body>", sep="")
		tmp = paste(tmp, "<GetBondTypes></GetBondTypes>", sep="")
		tmp = paste(tmp, "</soap:Body></soap:Envelope>", sep="")

		bondtypes = basicTextGatherer()
		curlPerform(url = THAPI,  
			httpheader=c('Accept'="text/xml", 'Accept'="multipart/*",'Content-Type'="text/xml; charset=utf-8", SOAPAction=THWS), 
			postfields=tmp, writefunction=bondtypes$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))

		ret <- data.frame() 
		
		xmlTreeParse(bondtypes$value(), handlers=list(bondTypeList=function(x){
				i<-1;
                                while(i<=length(x)){
                                        ret <<- rbind(ret, data.frame(
                                                value=xmlValue(x[i]$data[3]$value),
                                                longName=xmlValue(x[i]$data[4]$longName)))
                                        i <- i+1
                                }
                        }), asTree=TRUE)		
		ret
	}
)

##############
# GetVersion 
#
#

setGeneric("getVersion", function(this) standardGeneric("getVersion"))
setMethod("getVersion", signature(this="rdth"), 
	function(this){
		tmp = serialize(this)
		tmp = paste(tmp, "<soap:Body>", sep="") 
		tmp = paste(tmp, "<GetVersion></GetVersion>",sep="")
		tmp = paste(tmp, "</soap:Body></soap:Envelope>", sep="")

		version = basicTextGatherer()
		curlPerform(url = THAPI,  
			httpheader=c('Accept'="text/xml", 'Accept'="multipart/*",'Content-Type'="text/xml; charset=utf-8", 
			SOAPAction=THWS), postfields=tmp, 
			writefunction=version$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))

		ret <- list()
		xmlTreeParse(version$value(), handlers=list(version=function(x){ 
			o <- new("Version", servlet=xmlValue(x[1]$servlet), backend=xmlValue(x[2]$backend))	
			ret <<- o
		}), asTree=TRUE)

		ret
	}
)



############
# GetQuota
#
# The GetQuota call returns the RIC quota type of the user, the number of Cash RICs used, the maximum number of Cash RICs allowed, the number of Option RICs used, the maximum number of Option RICs allowed, the number of Future RICs used, the maximum number of Future RICs allowed, and whether the user is allowed to exceed the maximum (up to a hard limit). 
#
# For compliace users, usedCash is the number of RICs used regardless of category and totalCash is the maximum number of RICS allowed regardless of category.  The fields usedOption, totalOption, usedFuture, and totalFuture will be zero.

setGeneric("getQuota", function(this) standardGeneric("getQuota"))
setMethod("getQuota", signature(this="rdth"), 
	function(this){
		tmp=serialize(this)
		tmp=paste(tmp, "<soap:Body>", sep="")
		tmp=paste(tmp, "<GetQuota></GetQuota>", sep="")
		tmp = paste(tmp, "</soap:Body></soap:Envelope>", sep="")

		quota = basicTextGatherer() 
		curlPerform(url = THAPI,  httpheader=c('Accept'="text/xml", 'Accept'="multipart/*",'Content-Type'="text/xml; charset=utf-8", 
				SOAPAction=THWS), postfields=tmp, writefunction=quota$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))
		

		ret <- list()
		xmlTreeParse(quota$value(), handlers=list(result=function(x){
			o <- new("Quota",type=new("QuotaType", value=xmlValue(x[1]$type)), usedCash=xmlValue(x[2]$usedCash),totalCash=xmlValue(x[3]$totalCash), usedOption=xmlValue(x[4]$usedOption), 
				totalOption=xmlValue(x[5]$totalOption), usedFuture=xmlValue(x[6]$usedFuture), totalFuture=xmlValue(x[7]$totalFuture), exceedable=xmlValue(x[8]$exceedable))     
			ret <<- o
			}), asTree=TRUE)	

		ret			
	}
)




setGeneric("getRestrictedPEs", function(this) standardGeneric("getRestrictedPEs"))
setMethod("getRestrictedPEs", signature(this="rdth"),
	function(this){
		tmp = serialize(this)
		tmp = paste(tmp, "<soap:Body>", sep="")
		tmp = paste(tmp, "<GetRestrictedPEs/>", sep="")
		tmp = paste(tmp, "</soap:Body></soap:Envelope>", sep="")
		tmp

		restrictedpes = basicTextGatherer()
		curlPerform(url = THAPI,  	
			httpheader=c('Accept'="text/xml", 'Accept'="multipart/*",'Content-Type'="text/xml; charset=utf-8", 
			SOAPAction=THWS), postfields=tmp, 
			writefunction=restrictedpes$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))
		
                
		ret <- data.frame() 
		xmlTreeParse(restrictedpes$value(), handlers=list(restrictedPEList=function(x){
				i<-1
				while(i<=length(x)){
					ret <<- rbind(ret, data.frame(value=xmlValue(x[i]$data[3]$value), 
						longName=xmlValue(x[i]$data[4]$longName)))	
			
					i <- i+1
				}
			}), asTree=TRUE)
ret	
	}
)

#################
# GetAssetDomains
#
# Returns a list of supported Asset Domains - an asset domain represents market segmentation, e.g. Equities, Futures, Options or Indices. 
#
# Example: 
# getAssetDomains(rdth) 

setGeneric("getAssetDomains", function(this) standardGeneric("getAssetDomains"))
setMethod("getAssetDomains", signature(this="rdth"),
	function(this){
		tmp = serialize(this)
		tmp = paste(tmp, "<soap:Body>", sep="")
		tmp = paste(tmp, "<GetAssetDomains></GetAssetDomains>", sep="")
		tmp = paste(tmp, "</soap:Body>", "</soap:Envelope>", sep="")
		tmp

		assetdom = basicTextGatherer()
		curlPerform(url = THAPI,  httpheader=c('Accept'="text/xml", 'Accept'="multipart/*",'Content-Type'="text/xml; charset=utf-8", 
				   SOAPAction=THWS), postfields=tmp, writefunction=assetdom$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))
	

		ret <- data.frame()	
		xmlTreeParse(assetdom$value(), handlers=list(domainList=function(x){
				i<-1
				while(i<=length(x)){
					ret <<- rbind(ret, data.frame(  
						value=xmlValue(x[i]$data[3]$value), 
						longName=xmlValue(x[i]$data[4]$longName)))	
			
					i <- i+1
				}
			}), asTree=TRUE)
		ret	
	
	}
)


##################
# GetCreditRatings 
#
# Returns a list of credit Rating codes applica

setGeneric("getCreditRatings", function(this) standardGeneric("getCreditRatings"))
setMethod("getCreditRatings", signature(this="rdth"), 
	function(this){
		tmp = serialize(this)
		tmp = paste(tmp, "<soap:Body>", sep="")
		tmp = paste(tmp, "<GetCreditRatings/>", sep="")
		tmp = paste(tmp, "</soap:Body>", "</soap:Envelope>", sep="")
			

		creditratings = basicTextGatherer()
		curlPerform(url = THAPI,  
			httpheader=c('Accept'="text/xml", 'Accept'="multipart/*",'Content-Type'="text/xml; charset=utf-8", 
			SOAPAction=THWS), postfields=tmp, 
			writefunction=creditratings$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))
			
		ret <- data.frame() 
		xmlTreeParse(creditratings$value(), handlers=list(creditRatingList=function(x){
				i<-1
				while(i<=length(x)){
					ret <<- rbind(ret, data.frame(
						value=xmlValue(x[i]$data[3]$value), 
						longName=xmlValue(x[i]$data[4]$longName)))	
					i <- i+1
				}
			}), asTree=TRUE)
		ret	
	}
)	
 


##########################
# GetFuturesDeliveryMonths
#
# Returns a list of delivery month codes for instruments from the Futures domain. 
#
# Example: 
# getFuturesDeliveryMonths(rdth) 


setGeneric("getFuturesDeliveryMonths", function(this) standardGeneric("getFuturesDeliveryMonths"))
setMethod("getFuturesDeliveryMonths", signature(this="rdth"),
	function(this){
		tmp = serialize(this)
		tmp = paste(tmp, "<soap:Body>", sep="")
		tmp = paste(tmp, "<GetFuturesDeliveryMonths/>", sep="")
		tmp = paste(tmp, "</soap:Body>", "</soap:Envelope>", sep="")

		futuresdelivery = basicTextGatherer()
		curlPerform(url = THAPI,  
				httpheader=c('Accept'="text/xml", 'Accept'="multipart/*",'Content-Type'="text/xml; charset=utf-8", 
				SOAPAction=THWS), postfields=tmp, writefunction=futuresdelivery$update, 
				verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))
		ret <- data.frame() 
		xmlTreeParse(futuresdelivery$value(), handlers=list(monthList=function(x){
				i<-1
				while(i<=length(x)){
					ret <<- rbind(ret,data.frame( 
						value=xmlValue(x[i]$data[3]$value), 
						longName=xmlValue(x[i]$data[4]$longName)))	
					i <- i+1
				}
			}), asTree=TRUE)
		ret	
	}
)


#######################
# GetOptionExpiryMonths 
# 
# Returns a list of option expiry Month codes for instruments from the Options domain. 
#
# Example: 
# GetOptionExpiryMonths(rdth) 

setGeneric("getOptionExpiryMonths", function(this) standardGeneric("getOptionExpiryMonths"))
setMethod("getOptionExpiryMonths", signature(this="rdth"), 
	function(this){
		tmp = serialize(this)
		tmp = paste(tmp, "<soap:Body>", sep="")
		tmp = paste(tmp, "<GetOptionExpiryMonths/>", sep="")
		tmp = paste(tmp, "</soap:Body>", "</soap:Envelope>", sep="")

		optionexpiry = basicTextGatherer()
		curlPerform(url = THAPI,  httpheader=c('Accept'="text/xml", 'Accept'="multipart/*",'Content-Type'="text/xml; charset=utf-8", SOAPAction=THWS), postfields=tmp, writefunction=optionexpiry$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))

		ret <- list(); 
		xmlTreeParse(optionexpiry$value(), handlers=list(monthList=function(x){
				i<-1; 
				while(i<=length(x)){
					o <- new("Data",type=xmlValue(x[i]$data[1]$type), 
						field=xmlValue(x[i]$data[2]$field), 
						value=xmlValue(x[i]$data[3]$value), 
						longName=xmlValue(x[i]$data[4]$longName))		
					ret <<- c(ret, o) 
					i <- i+1 
				}
			}), asTree=TRUE)
		ret
	}
)



###################
# GetInstrumenTypes
#
# Returns a list of supported Instrument Types for a given list of Asset Domains - an instrument type is a sub class domain, e.g. Equity-linked or Grain and Oilseed Commodities. 
#
# Example: 
# getInstrumentTypes(rdth, domains=c("EQU")) 
 
setGeneric("getInstrumentTypes", function(this, domains) standardGeneric("getInstrumentTypes"))   
setMethod("getInstrumentTypes", signature(this="rdth", domains="vector"), 
	function(this,domains){
		tmp = serialize(this) 
		tmp = paste(tmp, "<soap:Body>", sep="")
		domainList = new("DomainList",data=domains) 
		tmp = paste(tmp, "<GetInstrumentTypes>",serialize(domainList), "</GetInstrumentTypes>", sep="")
		tmp = paste(tmp, "</soap:Body>", "</soap:Envelope>", sep="")

		instrumenttypes = basicTextGatherer()
		curlPerform(url = THAPI,  
			httpheader=c('Accept'="text/xml", 'Accept'="multipart/*",'Content-Type'="text/xml; charset=utf-8", 
					SOAPAction=THWS), postfields=tmp, 
					writefunction=instrumenttypes$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))
	
		ret <- data.frame()
		#deserialize functions
		xmlTreeParse(instrumenttypes$value(), handlers=list(instrumentTypeList=function(x){
					i<-1;
					while(i<=length(x)){
						ret <<- rbind(ret, data.frame(value=as.integer(xmlValue(x[i]$data[3]$value)), longName=xmlValue(x[i]$data[4]$longName)))
						i<-i+1
					}
				}), asTree=TRUE)
		ret 
	}
)

#################
# GetMessageTypes
#
# Return a list of supported message types for a given list of Asset Domains and request type.  The GetMessageTypes operation is unique in that it returns an array of <MessageTypes> instead of the generic 
# <Data> elements. 
#
# Example: 
# getMessageTypes(rdth, domains=c("EQU"), requesttype="TimeAndSales") 

setGeneric("getMessageTypes", function(this,domains, requesttype) standardGeneric("getMessageTypes")) 
setMethod("getMessageTypes", signature(this="rdth", domains="vector", requesttype="character"), 
	function(this, domains, requesttype){
		tmp = serialize(this)
		tmp = paste(tmp, "<soap:Body>", sep="")
		domainList = new("DomainList", data=domains)
		tmp = paste(tmp, "<GetMessageTypes>", sep="")
		tmp = paste(tmp, serialize(domainList), sep="")
		tmp = paste(tmp, "<requestType>", requesttype, "</requestType>", sep="")
		tmp = paste(tmp, "</GetMessageTypes>", sep="") 
		tmp = paste(tmp, "</soap:Body></soap:Envelope>", sep="")

		messagetypes = basicTextGatherer()
		curlPerform(url = THAPI,  httpheader=c('Accept'="text/xml", 'Accept'="multipart/*",'Content-Type'="text/xml; charset=utf-8", SOAPAction=THWS), postfields=tmp, writefunction=messagetypes$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))


		messagetypes$value() 
		ret <- data.frame()
	 	
		xmlTreeParse(messagetypes$value(), handlers=list(messageTypeList=function(x){
			       i<-1
                               while(i<=length(x))
			       {
					j <- 1 
					fields <- vector()
					fieldStr <- "" 

					while(j <= length(x[i]$messageType[2]$fieldList)){
						fields <- c(fields, x[i]$messageType[2]$fieldList[j]$string)									   
						if (j == 1 ){
							fieldStr <- xmlValue(x[i]$messageType[2]$fieldList[j]$string) 
						}else{
							fieldStr <- paste(fieldStr, xmlValue(x[i]$messageType[2]$fieldList[j]$string), sep=",") 
						}
						j <- j +1 
					}
	
                                        o <- new("MessageType", name=xmlValue(x[i]$messageType[1]$name), fieldList=new("FieldList",data=fields))
						
                                        ret <<- rbind(ret, data.frame(MessageType=xmlValue(x[i]$messageType[1]$name), FieldList=fieldStr)) 
                                        i <- i+1
                                }
                        }), asTree=TRUE)		
		ret 
	}
)




###################
# GetInFlightStatus
# 
# InflightStatus provides information on number of actively running requests (in-flight) as well as the 
# request IDs of all the jobs that have completed and are ready to download.  This saves the user from 
# continuously polling for many request IDs using GetRequestResult.  The user should use this method over 
# GetRequestResult where possible.  The in-flight limit should be respected, and the user should stop submitting 
# any more requests when the number of active request reaches the limit. 
#
# Example: 
# getInFlightStatus(rdth)

setGeneric("getInFlightStatus", function(this) standardGeneric("getInFlightStatus"))
setMethod("getInFlightStatus", signature(this="rdth"),
	function(this){
		tmp = serialize(this)
		tmp = paste(tmp, "<soap:Body>", sep="")
		tmp = paste(tmp, "<GetInflightStatus/>", sep="")
		tmp = paste(tmp, "</soap:Body></soap:Envelope>", sep="")	

		inflightstatus = basicTextGatherer()
		curlPerform(url = THAPI,  	
				httpheader=c('Accept'="text/xml", 'Accept'="multipart/*",'Content-Type'="text/xml; charset=utf-8", 
				SOAPAction=THWS), postfields=tmp,
				writefunction=inflightstatus$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))

		ret <- data.frame()

		xmlTreeParse(inflightstatus$value(), handlers=list(status=function(x){
				i <- 1
				r <- vector()
				while(i<=length(x[3]$completed)){
					r = c(r, xmlValue(x[3]$completed[i]$string))	
					i <- i+ 1
				}		

				ret <<- new("InFlightStatus", active=xmlValue(x[1]$active), limit=xmlValue(x[2]$limit), completed=r)	
			}), asTree=TRUE)
		ret
	}
)
		



#################
# Search RICs 
#
# Search for instruments across domains, exchanges or instrument types 
#
# Example: 
# searchRICs(rdth, "2011-11-11", "2011-11-12", "EQU", "ASX", "^BHP.*")

setGeneric("searchRICs", function(this, startdate, enddate, domain, exchange, ricregex) standardGeneric("searchRICs"))
setMethod("searchRICs", signature(this="rdth", "character", "character", "character", "character", "character"),  	
	function(this, startdate, enddate, domain, exchange, ricregex){
		tmp = paste(serialize(this), "<soap:Body>", "<SearchRICs xmlns='http://types.webservice.tickhistory.thomsonreuters.com'>",sep="")
		daterange = new("DateRange", start=startdate, end=enddate)
		tmp = paste(tmp, serialize(daterange), sep="")	
		param = new("ArrayOfData",v=c(
				new("Data", field="Domain",   value=domain),
				new("Data", field="Exchange", value=exchange),
				new("Data", field="RICRegex", value=ricregex)
				)) 
		criteria = new("Criteria", d=param) 
		tmp = paste(tmp, serialize(criteria), sep="")  
		tmp = paste(tmp, "<refData>false</refData></SearchRICs></soap:Body></soap:Envelope>", sep="")

		search = basicTextGatherer()
		curlPerform(url = THAPI, 
				 httpheader=c('Accept'="text/xml", 'Accept'="multipart/*",
				'Content-Type'="text/xml; charset=utf-8", 
				SOAPAction=THWS), 
				postfields=tmp, writefunction = search$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))

		ret <- data.frame() 
		xmlTreeParse(search$value(), handlers=list(instrument=function(x){
				ret <<- rbind(ret, data.frame(code=xmlValue(x[1]$code), startdate=xmlValue(x[2]$dateRange[1]$start), enddate=xmlValue(x[2]$dateRange[2]$end), status=xmlValue(x[3]$status)))	
			}), asTree=TRUE)  	
		ret	
	}
)


# Parse the input fields into a MessageTypeList 
parseFields <- function(f){
# Input string: MessageType1:Field1,Field2;MessageType2:Field1,Field2;.... 
	lastpos <- 1
	curpos <- 1

	messagetypelist <- list() 
	msgtypename <- "" 
	fieldlist <- list() 

	while( curpos <= nchar(f)){	
		curchar <- substr(f, curpos,curpos)		

		if (curchar == ':'){	
			msgtypename <- substr(f, lastpos, curpos-1)		
			lastpos <- curpos+1		
		}else if (curchar == ','){	
			prevfield <- substr(f, lastpos,curpos-1) 
			fieldlist <- c(fieldlist, prevfield) 	
			lastpos <- curpos+1
				
		}else if (curchar == ';'){
			prevfield <- substr(f, lastpos, curpos-1)
			fieldlist <- c(fieldlist, prevfield)
			
			messagetypelist <- c(messagetypelist, new("MessageType", name=msgtypename, fieldList=new("FieldList", data=fieldlist)))	
			lastpos <- curpos+1 	

			msgtypename <- ""
			fieldlist <- list()
		}
		substr(f, lastpos, curpos-1)		
		curpos <- curpos +1	
	}  

	if (nchar(msgtypename) > 0){
		prevfield <- substr(f, lastpos, curpos-1)
		fieldlist <- c(fieldlist, prevfield)	
		messagetypelist <- c(messagetypelist, new("MessageType", name=msgtypename, fieldList=new("FieldList", data=fieldlist))) 
	}

	messagetypelist	
		
}



####################
# Submit FTP Request 
#
# Example: 
# submitFTPRequest(rdth, "test", "BHP.AX;ASX.AX", "2011-11-08", "2011-11-12", "00:00:00", "23:59:59.999", "TimeAndSales", mktdepth="0", "Trade:Price,Volume;Quote:Bid Price,Ask Price")

setGeneric("submitFTPRequest", function(r, friendlyname, instrumentList, startdate, enddate, starttime, endtime, reqtype, mktdepth, messagetypelist,...) standardGeneric("submitFTPRequest"))
setMethod("submitFTPRequest", signature(r="rdth", friendlyname="character", instrumentList="character", startdate="character", enddate="character", starttime="character", endtime="character", reqtype="character", mktdepth="character", messagetypelist="character"), 
	function(r, friendlyname, instrumentList, startdate, enddate, starttime, endtime, reqtype, mktdepth,messagetypelist,reqInGMT="false", disInGMT="false"){
		tmp <- paste(serialize(r), "<soap:Body>", "<SubmitFTPRequest xmlns='http://types.webservice.tickhistory.thomsonreuters.com'>",sep="")
                instrumentlist <- new("InstrumentList",data=unlist(strsplit(instrumentList, ";"))) 
                daterange <- new("DateRange",start=startdate,end=enddate)  
                timerange <- new("TimeRange",start=starttime,end=endtime)
                messageTypeList <- new ("MessageTypeList", data=new ("ArrayOfData", v=parseFields(messagetypelist)))
                largeRequestSpec <- new("LargeRequestSpec",friendlyName=friendlyname,requestType=reqtype,instrumentList=instrumentlist,dateRange=daterange,timeRange=timerange, messageTypeList=messageTypeList,
					requestInGMT=reqInGMT, displayInGMT=disInGMT, marketDepth=mktdepth,splitSize="50",delivery="Pull",sortType="RICSequence", fileFormat="Single", dateFormat="YYYYMMDD", 
					disableDataPersistence="false", includeCurrentRIC="false", applyCorrections="false", displayMicroseconds="true") 
                tmp <- paste(tmp, serialize(largeRequestSpec), sep="") 
                tmp <- paste(tmp, "</SubmitFTPRequest></soap:Body></soap:Envelope>", sep="")

		submitftp = basicTextGatherer()
		curlPerform(url = THAPI,  httpheader=c('Accept'="text/xml", 'Accept'="multipart/*",'Content-Type'="text/xml; charset=utf-8", SOAPAction=THWS), postfields=tmp, writefunction = submitftp$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))

		outputfile_name <- ""
		xmlTreeParse(submitftp$value(), handlers=list(
				SubmitFTPRequestResponse=function(x){
					outputfile_name <<- xmlValue(x[1]$requestID)
				}, 
				Fault=function(x){ 
                                        stop(xmlValue(x[2]$faultstring))
                                }))	
		
		if (nchar(outputfile_name) <= 0){
			stop(paste("Server Error Message: ",submitftp$value(), sep=" "))
		}
		
		print(paste("Your request id is:", outputfile_name, sep=" "))
	}
)





################
# Submit Request 
# Submit a data request for a single instrument for a single day for batch processing 
#
# Example:
# submitRequest(rdth, "test", "BHP.AX", "2011-11-11", "00:00:00", "23:59:59.999", "TimeAndSales", mktdepth="0", messagetypelist="Trade:Price,Volume;Quote:Bid Price,Ask Price")

setGeneric("submitRequest", function(r, friendlyname, instrument, date, starttime, endtime , reqtype,mktdepth,messagetypelist,...) standardGeneric("submitRequest"))
setMethod("submitRequest", signature(r="rdth", friendlyname="character", instrument="character", date="character", starttime="character", endtime="character", reqtype="character",mktdepth="character", messagetypelist="character"),
	function(r, friendlyname, instrument,date,starttime,endtime,reqtype,mktdepth, messagetypelist,reqInGMT="false",disInGMT="false"){
		tmp <- paste(serialize(r), "<soap:Body>", "<SubmitRequest xmlns='http://types.webservice.tickhistory.thomsonreuters.com'>", sep="")
		instrument1 <- new("Instrument", code=instrument)

		timerange <- new("TimeRange", start=starttime, end=endtime)

		messagetypelist1 <- new ("MessageTypeList", data=new("ArrayOfData", v=parseFields(messagetypelist)))

		requestSpec <- new("RequestSpec", friendlyName=friendlyname,requestType=reqtype,instrument=instrument1,date=date,timeRange=timerange,messageTypeList=messagetypelist1,requestInGMT=reqInGMT,
				displayInGMT=disInGMT,disableHeader="false",marketDepth=mktdepth,dateFormat="YYYYMMDD",disableDataPersistence="false",includeCurrentRIC="true",applyCorrections="false",displayMicroseconds="true")

		tmp <- paste(tmp, serialize(requestSpec), sep="")	
		tmp <- paste(tmp, "</SubmitRequest></soap:Body></soap:Envelope>", sep="")
		
		submitrequest = basicTextGatherer()

		curlPerform(url=THAPI, httpheader=c('Accept'="text/xml", 'Accept'="multipart/*",
			'Content-Type'="text/xml; charset=utf-8", 
			SOAPAction=THWS), 
			postfields=tmp, writefunction = submitrequest$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))   
		
		outputfile_name <- ""

		xmlTreeParse(submitrequest$value(), handlers=list(SubmitRequestResponse=function(x){
				outputfile_name <<- xmlValue(x[1]$requestID)}, Fault=function(x){ 
                                        stop(xmlValue(x[2]$faultstring))
                                }))
		
		print(paste("Submitted request:", outputfile_name, sep=" "))
	
		# Poll server to see when the data is ready
 
		# total seconds before timeout, 5 minutes
		timeout <- 300 

		# check every 10 seconds
		checkinterval <- 10

		i <- 0

		dataisready <- FALSE
		while(i < timeout && !dataisready ){
			print("Polling InFlightStatus to check if request is ready ")	
			ret <- getInFlightStatus(r)	
			c = 1
			while(c <= length(ret@completed)){	
				if (ret@completed[c] == outputfile_name){
					# reset time out so the previous loop exit
					print("Request is completed")				
					dataisready <- TRUE
					break
				}
				c <- c+1
			}
				
			Sys.sleep(checkinterval)	
			i <- i+checkinterval
		}
		if (i >= timeout){
			stop("No data has returned within the timeout period.")
		}	
			
		print("Getting request result")
		getRequestResult(r, outputfile_name, loaddata="yes", reqtype) 		
	}
)


#################
# TH Loader 
#
# rdthLoader(file)
#
#

rdthLoader <- function(f, sep = ","){
	input_dataframe <- read.csv(f, sep=sep)
        RTime <- as.POSIXct(apply(input_dataframe[,3:4], MARGIN=1, FUN=function(x){paste(paste(substr(x[1], 1, 4),substr(x[1],5,6),substr(x[1],7,8),sep="-"), substr(x[2], 1, 15))} ), "GMT")
	new_dataframe <- data.frame(RIC=input_dataframe[,1],RTime, input_dataframe[,2:ncol(input_dataframe)])
}	


#################
# TH Loader for Corporate Actions
#
# rdthCALoader(file)
#
#

rdthCALoader <- function(f, sep = ","){
        input_dataframe <- read.csv(f, sep=sep)
        new_dataframe <- data.frame(input_dataframe)
}










#########
# Get Request Result
# Retrieve the resulting data from a previously submitted data request 
#
#setGeneric("getRequestResult", function(r, requestid, loaddata) standardGeneric("getRequestResult"))
#setMethod("getRequestResult", signature(r="rdth", requestid="character", loaddata="character"), 
getRequestResult <- function(r, requestid, loaddata="no", reqtype){
		tmp <- paste(serialize(r), "<soap:Body>", "<GetRequestResult>", sep="")
		tmp <- paste(tmp, "<requestID>", requestid, "</requestID>", sep="") 
		tmp <- paste(tmp, "</GetRequestResult></soap:Body></soap:Envelope>", sep="")										
		requestresult = basicTextGatherer()

		curlPerform(url=THAPI, httpheader=c('Accept'="text/xml", 'Accept'="multipart/*", 
			'Content-Type'="text/xml; charset=utf-8", SOAPAction=THWS), 
			postfields=tmp, writefunction=requestresult$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep="")) 
				
		output_tmpfile = paste(Sys.getenv("TMPDIR"),requestid, ".base64", sep="")     
		output_resultfile = paste(Sys.getenv("TMPDIR"),requestid, ".csv.gz", sep="")	

		status <- "Processing"
		havedata <- "No"
		xmlTreeParse(requestresult$value(), handlers=list(
				result=function(x){	
					status <<- xmlValue(x[1]$status)
					if (loaddata=="yes"){
						havedata <<- "Yes"
						write(xmlValue(x[2]$data), output_tmpfile)
						decode(output_tmpfile, output_resultfile)
					}
				}, 
				Fault=function(x){ 
					stop(xmlValue(x[2]$faultstring))	
				}),asTree=TRUE)  
		
		
		if (havedata == "Yes"){		
			#Convert time in POSIXlt 
                        if (reqtype == "CorporateActions"){
                        rdthCALoader(gzfile(output_resultfile))    
                        }
			else{
			rdthLoader(gzfile(output_resultfile))}
		}
		else{
			print(status)		
		}
	}
#)



#################
# Cancel Request
# Cancels and removes the results file for a request (either a normal API request or an FTP request) 

setGeneric("cancelRequest", function(r, friendlyname) standardGeneric("cancelRequest"))
setMethod("cancelRequest", signature(r="rdth", friendlyname="character"), 
	function(r, friendlyname){
		tmp <- paste(serialize(r), "<soap:Body>", "<CancelRequest>", sep="")
		tmp <- paste(tmp, "<requestID>", friendlyname, "</requestID>", sep="")
		tmp <- paste(tmp, "</CancelRequest></soap:Body></soap:Envelope>", sep="")

		cancelrequest = basicTextGatherer() 

		curlPerform(url=THAPI, httpheader=c('Accept'="text/html", 'Accept'="multipart/*",
			'Content-type'="text/html; charset=utf-8", SOAPAction=THWS), 
			postfields=tmp, writefunction=cancelrequest$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep="")) 
	}
)

###########
# Clean Up
# The CleanUp call aborts all queued and running non-FTP requests, and in addition, 
# removes complete non-FTP requests that have not been downloaded.  
# The operation allows users to start the API with a clean slate.  This should be called at the start of your programs.
# 
# Note that the CleanUp call does not have any impact on FTP (push or pull) requests, 
# it will not clean up the result files generated by FTP requests and will not abort running FTP requests.

setGeneric("cleanUp", function(r) standardGeneric("cleanUp"))
setMethod("cleanUp", signature(r="rdth"), 
	function(r){
		tmp <- paste(serialize(r), "<soap:Body>", "<CleanUp>", sep="")
		tmp <- paste(tmp, "</CleanUp></soap:Body></soap:Envelope>", sep="")

		cleanuprequest = basicTextGatherer()

		curlPerform(url=THAPI, httpheader=c('Accept'="text/html", 'Accept'="multipart/*",
			'Content-type'="text/html; charset=utf-8", SOAPAction=THWS), 
			postfields=tmp, writefunction=cleanuprequest$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep="")) 
	}
) 

##############
# ExpandChains
#
# Expand a chain RIC to its instrument constituents over a date range or an instance in time (in this case the start and end dates are the same); a list of instruments is returned.
#
#
setGeneric("expandChains", function(r, ric, startdate, enddate, starttime, endtime, requestInGMT) standardGeneric("expandChains")) 
setMethod("expandChains", signature(r="rdth", ric="character", startdate="character", enddate="character", starttime="character", endtime="character", requestInGMT="character"), 
	function(r, ric, startdate, enddate, starttime, endtime, requestInGMT){
		dateRange <- new("DateRange", start=startdate, end=enddate)
		instrument <- new("Instrument", code=ric)
		timeRange <- new("TimeRange", start=starttime, end=endtime)
		
		tmp <- paste(serialize(r), "<soap:Body>", "<ExpandChain ", THNS, ">", sep="")
	
		tmp <- paste(tmp, serialize(instrument), sep="")
		tmp <- paste(tmp, serialize(dateRange), sep="")
		tmp <- paste(tmp, serialize(timeRange), sep="")	
		tmp <- paste(tmp, "<requestInGMT>",requestInGMT, "</requestInGMT>")
		tmp <- paste(tmp, "</ExpandChain></soap:Body></soap:Envelope>", sep="")	
		
		expandchainsrequest = basicTextGatherer()
		
		curlPerform(url=THAPI, httpheader=c('Accept'="text/html", 'Accept'="multipart/*",
				'Content-type'="text/html; charset=utf-8", SOAPAction=THWS), 
				postfields=tmp, writefunction=expandchainsrequest$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))
		
		ret <- data.frame()
		xmlTreeParse(expandchainsrequest$value(), handlers=list(instrumentList=function(x){
				i<-1
				while(i <= length(x)){
					ret <<- rbind(ret, data.frame(code=xmlValue(x[i]$instrument[1]$code)))	
					i<-i+1
				}	
			}
		))	
		ret
	}
)

#############
# Verify RICs
# Query the validity of an instrument and optionally return its reference data. The instrument must be
# specified by RIC or, if permissioned, by ISIN, CUSIP or SEDOL.
setGeneric("verifyRICs", function(r, startdate,enddate, rics, refData) standardGeneric("verifyRICs"))
setMethod("verifyRICs", signature(r="rdth", startdate="character", enddate="character", rics="vector", refData="character"), 
 	function(r, startdate,enddate, rics, refData){	
		arrayOfInstrument <- new("InstrumentList",  data=rics) 

		tmp <- paste(serialize(r), "<soap:Body>", "<VerifyRICs ",THNS,">", sep="")	
		dateRange <- new("DateRange", start=startdate, end=enddate)
		tmp <- paste(tmp, serialize(dateRange), sep="")
		tmp <- paste(tmp, serialize(arrayOfInstrument), sep="") 
		tmp <- paste(tmp,"<refData>", refData, "</refData>", sep="")
		tmp <- paste(tmp, "</VerifyRICs></soap:Body></soap:Envelope>", sep="")
	
		verifyrics = basicTextGatherer()
		curlPerform(url=THAPI, httpheader=HTTPHEADER, postfields=tmp, 
			    writefunction=verifyrics$update, verbose=FALSE, cainfo=paste(system.file(package="RCurl"), "/CurlSSL/ca-bundle.crt", sep=""))

		ret <- data.frame()

		xmlTreeParse(verifyrics$value(), handlers=list(verifiedList=function(x){
			i<-1	
			while(i<=length(x)){	
				fieldnum <- 1	
				isin <- vector()		
				cusip <- vector()
				sedol <- vector()
				gics <- vector()
				name <- vector()
				exchange <- vector()
				type <- vector()
				strikePrice <- vector()
				bondType <- vector()
				maturityDate <- vector()
				couponDate <- vector()	
				creditRating <- vector()
				currency <- vector()
				peCode <- vector()
				dateRange <- new("DateRange", start="-",end="-")

				while(fieldnum <= length(x[i]$instrument)){
					b <- c("isin","cusip","sedol","gics","name","exchange","type","expiryDate","strikePrice","maturityDate","couponDate","bondType","creditRating","currency") 

					
					if (length(x[i]$instrument[fieldnum]$dateRange) > 0){
						dateRange <- new("DateRange", start=xmlValue(x[i]$instrument[fieldnum]$dateRange[1]$start),end=xmlValue(x[i]$instrument[fieldnum]$dateRange[2]$end))
					}

					j <- 1
					while(j<=length(x[i]$instrument[fieldnum]$isin)){
						isin <- c(isin, xmlValue(x[i]$instrument[fieldnum]$isin[j]$string))
						j<-j+1
					}

					j<-1
					while(j<=length(x[i]$instrument[fieldnum]$cusip)){
						cusip <- c(cusip, xmlValue(x[i]$instrument[fieldnum]$cusip[j]$string)) 
						j<-j+1
					}

					j<-1
					while(j<=length(x[i]$instrument[fieldnum]$sedol)){
						sedol <- c(sedol, xmlValue(x[i]$instrument[fieldnum]$sedol[j]$string)) 
						j<-j+1
					}


					j<-1
					while(j<=length(x[i]$instrument[fieldnum]$gics)){
						gics <- c(gics, xmlValue(x[i]$instrument[fieldnum]$gics[j]$string)) 
						j<-j+1
					}


					j<-1
					while(j<=length(x[i]$instrument[fieldnum]$name)){
						name <- c(name, xmlValue(x[i]$instrument[fieldnum]$name[j]$string)) 
						j<-j+1
					}
					

					j<-1
					while(j<=length(x[i]$instrument[fieldnum]$exchange)){
						exchange <- c(exchange, xmlValue(x[i]$instrument[fieldnum]$exchange[j]$string)) 
						j<-j+1
					}


					j<-1
					while(j<=length(x[i]$instrument[fieldnum]$type)){
						type <- c(type, xmlValue(x[i]$instrument[fieldnum]$type[j]$string)) 
						j<-j+1
					}


					j<-1
					while(j<=length(x[i]$instrument[fieldnum]$strikePrice)){
						strikePrice <- c(strikePrice, xmlValue(x[i]$instrument[fieldnum]$strikePrice[j]$string)) 
						j<-j+1
					}

					j<-1
					while(j<=length(x[i]$instrument[fieldnum]$maturityDate)){
						maturityDate <- c(maturityDate, xmlValue(x[i]$instrument[fieldnum]$maturityDate[j]$string)) 
						j<-j+1
					}

					j<-1
					while(j<=length(x[i]$instrument[fieldnum]$couponDate)){
						couponDate <- c(couponDate, xmlValue(x[i]$instrument[fieldnum]$couponDate[j]$string)) 
						j<-j+1
					}

					j<-1
					while(j<=length(x[i]$instrument[fieldnum]$creditRating)){
						creditRating <- c(creditRating, xmlValue(x[i]$instrument[fieldnum]$creditRating[j]$string)) 
						j<-j+1
					}

					j<-1
					while(j<=length(x[i]$instrument[fieldnum]$currency)){
						currency <- c(currency, xmlValue(x[i]$instrument[fieldnum]$currency[j]$string)) 
						j<-j+1
					}

					j<-1
					while(j<=length(x[i]$instrument[fieldnum]$peCode)){
						peCode <- c(peCode, xmlValue(x[i]$instrument[fieldnum]$peCode[j]$string)) 
						j<-j+1
					}		

					fieldnum <- fieldnum+1
				}
	
				#rbind - this does a row binding
				ret <<- rbind(ret,data.frame(code=xmlValue(x[i]$instrument[1]$code),
						isin=convertToString(isin),
						cusip=convertToString(cusip), 
						sedol=convertToString(sedol), 
						gics=convertToString(gics),
						name=convertToString(name),
						exchange=convertToString(exchange),			
						start=dateRange@"start", 
						end=dateRange@"end",
						type=convertToString(type),
						strikePrice=convertToString(strikePrice),
						maturityDate=convertToString(maturityDate),
						couponDate=convertToString(couponDate),creditRating=convertToString(creditRating),
						currency=convertToString(currency),
						peCode=convertToString(peCode)))			
					
				i<-i+1	
													
			}}
	
	))
	ret	
	}
)
